flowCore
========

Core flow infrastructure